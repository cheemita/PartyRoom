<?php

    $mysql = new mysqli("localhost", "root", "", "wpb");
    // if($mysql -> connect_errno){
    //     echo"<h1>We have here a connection error</h1>". $mysql-connect_errno;
    // }
    // else{
    //     echo"<h1>Success!</h1>";
    // }

?>